/* Stefan Sense Bundle independent example, MIT; no external dependencies. */
(() => { const scene = document.querySelector('.scene'); if (!scene) return;
const reduce = matchMedia('(prefers-reduced-motion: reduce)'); const coarse = matchMedia('(pointer: coarse)'); const layers = [...scene.querySelectorAll('[data-depth]')]; let active = true, frame = 0;
const draw = () => { frame = 0; const offset = -scene.getBoundingClientRect().top; layers.forEach(el => { const depth = Number(el.dataset.depth); const shift = reduce.matches || coarse.matches || depth === 4 ? 0 : Math.max(-100,Math.min(100,offset * (5-depth) * .035)); el.style.setProperty('--shift', `${shift}px`); }); };
const schedule = () => { if (active && !frame) frame = requestAnimationFrame(draw); };
if ('IntersectionObserver' in window) new IntersectionObserver(entries => { active = entries[0].isIntersecting; if (active) schedule(); }).observe(scene);
addEventListener('scroll', schedule, {passive:true}); addEventListener('resize', schedule); reduce.addEventListener('change',draw); coarse.addEventListener('change',draw); draw(); })();
